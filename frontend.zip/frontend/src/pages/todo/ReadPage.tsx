import { useCallback } from "react";
import { createSearchParams, useNavigate, useParams, useSearchParams } from "react-router-dom";

const ReadPage = () => {
  const { tno } = useParams();
  const navigate = useNavigate();

  const [queryParams] = useSearchParams();

  const page = queryParams.get("page") ? parseInt(queryParams.get("page")!) : 1;
  const size = queryParams.get("size") ? parseInt(queryParams.get("size")!) : 10;

  // 수정 화면으로 이동할 때 page, size 를 유지
  const queryStr = createSearchParams({ page: String(page), size: String(size) }).toString();

  const moveToModify = useCallback(
    (tno: string | undefined) => {
      navigate({ pathname: `/todo/modify/${tno}`, search: queryStr });
    },
    [navigate, queryStr],
  );

  return (
    <div className="text-3xl font-extrabold">
      Todo Read Page Component {tno}
      <div>
        <button onClick={() => moveToModify(tno)}>Test Modify</button>
      </div>
    </div>
  );
};

export default ReadPage;
