import { useNavigate, useParams } from "react-router-dom";

const ModifyPage = () => {
  // 교재는 props 로 tno 를 받지만, 라우터로 열리는 페이지라 useParams 로 꺼낸다
  const { tno } = useParams();
  const navigate = useNavigate();

  const moveToRead = () => {
    navigate({ pathname: `/todo/read/${tno}` });
  };

  const moveToList = () => {
    navigate({ pathname: `/todo/list` });
  };

  return (
    <div className="text-3xl font-extrabold">
      Todo Modify Page {tno}
      <div className="flex gap-4 text-xl">
        <button onClick={moveToRead}>Read</button>
        <button onClick={moveToList}>List</button>
      </div>
    </div>
  );
};

export default ModifyPage;
